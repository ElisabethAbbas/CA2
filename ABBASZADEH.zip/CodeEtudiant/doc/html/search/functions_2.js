var searchData=
[
  ['cfg',['Cfg',['../class_cfg.html#a5b3fde5a67f0d8fdc9fbc0a18a304c1b',1,'Cfg']]],
  ['comput_5fbasic_5fblock',['comput_basic_block',['../class_function.html#a6094f123294ccbb891fa4145fd5b1b0a',1,'Function']]],
  ['comput_5fcfg',['comput_CFG',['../class_program.html#a0d1d9386925418b5fd0a09bf5de16208',1,'Program']]],
  ['comput_5fcritical_5fpath',['comput_critical_path',['../class_dfg.html#af2212e74538c7e41980e8290b1981072',1,'Dfg']]],
  ['comput_5ffunction',['comput_function',['../class_program.html#aa2111257b1f690520316e4831e55798d',1,'Program']]],
  ['comput_5flabel',['comput_label',['../class_function.html#a1c8830219ce4306c22a933b17f54cc6f',1,'Function']]],
  ['comput_5fpred_5fsucc_5fdep',['comput_pred_succ_dep',['../class_basic__block.html#a2f2cdedde41f78b7982e6d6d348524c2',1,'Basic_block']]],
  ['comput_5fsucc_5fpred_5fbb',['comput_succ_pred_BB',['../class_function.html#a3c52c8cb82e0137f02771331018b655c',1,'Function']]],
  ['compute_5fdef_5fliveout',['compute_def_liveout',['../class_basic__block.html#a11eaa93c186fb46120bb6b0397e0c590',1,'Basic_block']]],
  ['compute_5fdom',['compute_dom',['../class_function.html#a9ecf8e774164937c3dfdb989ebe1c866',1,'Function']]],
  ['compute_5fin_5floop_5fbb',['compute_in_loop_BB',['../class_loop.html#a5ec7079fa8bbce34a18b41b768d3a118',1,'Loop']]],
  ['compute_5flive_5fvar',['compute_live_var',['../class_function.html#a21b614fb69692ba00240831c8fe8beb9',1,'Function']]],
  ['compute_5floops',['compute_loops',['../class_function.html#a20c7a6df3cb39a134fe5dcc9749bdf2e',1,'Function']]],
  ['compute_5fnb_5fdescendant',['compute_nb_descendant',['../class_dfg.html#ae2a0906df6dcb5831ec2201a071debe2',1,'Dfg']]],
  ['compute_5fuse_5fdef',['compute_use_def',['../class_basic__block.html#a7e91d5003b7941c50199ab22a8db0d17',1,'Basic_block']]]
];
