var searchData=
[
  ['nb_5fcycles',['nb_cycles',['../class_basic__block.html#a0a9caa9a904adc7807e390308e7b939c',1,'Basic_block']]],
  ['nb_5fpreds',['nb_preds',['../class_node__dfg.html#adef5e6e3362133f6adb38d404c8d8cf6',1,'Node_dfg']]],
  ['nbr_5fbb',['nbr_BB',['../class_loop.html#a333d1ba3bf5e448f7cd958c6d39beec2',1,'Loop::nbr_BB()'],['../class_function.html#a4ddde4ac1ff488dfcbfcaee71f727a48',1,'Function::nbr_BB()']]],
  ['nbr_5ffunc',['nbr_func',['../class_program.html#aa85073d3bd6782af3759f4a2961ae80f',1,'Program']]],
  ['nbr_5flabel',['nbr_label',['../class_function.html#a3f3807e12e695ffe23e1ef44edcd262b',1,'Function']]],
  ['node_5fdfg',['Node_dfg',['../class_node__dfg.html#ac9b79961aaadf29eecd03b227b4c0875',1,'Node_dfg']]]
];
