var searchData=
[
  ['read_5ftest',['read_test',['../class_dfg.html#a1a6dc2d38709c345177eec0d37ec43e2',1,'Dfg']]],
  ['reg_5frename',['reg_rename',['../class_basic__block.html#a800a558f4a20dfbd8528608b0fca3854',1,'Basic_block::reg_rename(list&lt; int &gt; *)'],['../class_basic__block.html#a1b6570f1c03c7f7435ab681c243151c9',1,'Basic_block::reg_rename()']]],
  ['reset_5fpred_5fsucc_5fdep',['reset_pred_succ_dep',['../class_basic__block.html#a4ef46cdfb1fa30e3edfc0407b008fa08',1,'Basic_block::reset_pred_succ_dep()'],['../class_instruction.html#a786e43bcd16d16a4db7c8a665c4d68af',1,'Instruction::reset_pred_succ_dep()']]],
  ['restitute',['restitute',['../class_dfg.html#a2598772fa5761e77dcb975048775602b',1,'Dfg']]],
  ['restitution',['restitution',['../class_basic__block.html#af74c4eeeecfb7a3f3fddbeb2994523a4',1,'Basic_block::restitution()'],['../class_cfg.html#a668d40acb10bfad95cf0d664e1522a7a',1,'Cfg::restitution()'],['../class_function.html#acd08be840c48abd3c0c0c20ca4b5192a',1,'Function::restitution()']]]
];
