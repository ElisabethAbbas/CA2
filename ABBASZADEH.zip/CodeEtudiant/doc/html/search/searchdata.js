var indexSectionsWithContent =
{
  0: "abcdefgilnoprstu~",
  1: "abcdfilnops",
  2: "bcdfilnop",
  3: "abcdefgilnoprst~",
  4: "dlu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

