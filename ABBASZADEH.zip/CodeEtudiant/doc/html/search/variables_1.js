var searchData=
[
  ['livein',['LiveIn',['../class_basic__block.html#ac772aedee0db949ff13844ee8a809e62',1,'Basic_block']]],
  ['liveout',['LiveOut',['../class_basic__block.html#a054946200a56d8c248f5a2ad7f1e1790',1,'Basic_block']]]
];
